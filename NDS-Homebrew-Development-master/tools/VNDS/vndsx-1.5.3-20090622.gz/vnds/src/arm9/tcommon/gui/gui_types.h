#ifndef T_GUI_TYPES_H
#define T_GUI_TYPES_H

class Button;
class ButtonListener;
class ConfirmScreen;
class GUI;
class Label;
class LabeledWidget;
class Screen;
class ScrollPane;
class Spinner;
struct SpinnerChoice;
class SpinnerListener;
class TextField;
class TextScrollPane;
class Widget;

#endif

