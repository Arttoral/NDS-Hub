#ifndef T_GUI_COMMON_H
#define T_GUI_COMMON_H

#include "gui_types.h"
#include "gui.h"
#include "screen.h"
#include "widget.h"
#include "button.h"
#include "scrollpane.h"
#include "spinner.h"
#include "textscrollpane.h"
#include "confirmscreen.h"
#include "label.h"
#include "labeledwidget.h"
#include "textfield.h"

#endif

